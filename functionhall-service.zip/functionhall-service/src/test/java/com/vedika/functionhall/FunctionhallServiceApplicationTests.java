package com.vedika.functionhall;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FunctionhallServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
