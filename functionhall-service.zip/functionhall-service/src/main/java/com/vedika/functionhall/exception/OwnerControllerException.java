package com.vedika.functionhall.exception;

public class OwnerControllerException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8231623027474402470L;

	public OwnerControllerException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}




}
