/*package com.vedika.functionhall.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vedika.functionhall.config.TwilioConfiguration;
import com.vedika.functionhall.repository.TwilioRepo;
@Service
public class TwilioCredentailsImpl implements TwilioCredentailService {
	@Autowired
	private static TwilioRepo twiliorepo;
	@Override
	public TwilioConfiguration getcredentails() {
		// TODO Auto-generated method stub
		return twiliorepo.find() ;
	}

}
*/