package com.vedika.functionhall.model;

public enum PaymentStatus {

    Pending,Failed,Success
}