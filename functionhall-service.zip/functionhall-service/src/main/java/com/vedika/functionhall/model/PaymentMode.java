package com.vedika.functionhall.model;

public enum PaymentMode {
	  NB,DC,CC
}
